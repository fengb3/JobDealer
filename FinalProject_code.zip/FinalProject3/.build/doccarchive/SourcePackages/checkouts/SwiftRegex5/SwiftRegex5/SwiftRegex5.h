//
//  SwiftRegex4.h
//  SwiftRegex4
//
//  Created by John Holdsworth on 24/11/2017.
//  Copyright © 2017 John Holdsworth. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftRegex4.
FOUNDATION_EXPORT double SwiftRegex4VersionNumber;

//! Project version string for SwiftRegex4.
FOUNDATION_EXPORT const unsigned char SwiftRegex4VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftRegex4/PublicHeader.h>



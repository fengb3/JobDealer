//
//  SignalRClient.h
//  SignalRClient
//
//  Created by Pawel Kadluczka on 2/23/17.
//  Copyright © 2017 Pawel Kadluczka. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SignalRClient.
FOUNDATION_EXPORT double SignalRClientVersionNumber;

//! Project version string for SignalRClient.
FOUNDATION_EXPORT const unsigned char SignalRClientVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SignalRClient/PublicHeader.h>



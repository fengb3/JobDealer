//
//  FinalProject3App.swift
//  FinalProject3
//
//  Created by 生物球藻 on 4/26/23.
//

import SwiftUI

@main
struct FinalProject3App: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}

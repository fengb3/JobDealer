namespace WebAPI.Models;

public interface IModel
{
    long Id { get; set; }
}